<?php
namespace Awz\Utm\Access\Custom;

class Helper
{
    public const ADMIN_DECLINE = 1;
}