<?php
namespace Awz\Utm\Access\Custom;

use Awz\Utm\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}