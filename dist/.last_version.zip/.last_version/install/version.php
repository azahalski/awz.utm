<?
$arModuleVersion = array(
	"VERSION" => "1.0.4",
	"VERSION_DATE" => "2025-01-18 11:25:00"
);
?>