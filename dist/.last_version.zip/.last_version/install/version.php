<?
$arModuleVersion = array(
	"VERSION" => "1.0.5",
	"VERSION_DATE" => "2025-01-18 11:40:00"
);
?>