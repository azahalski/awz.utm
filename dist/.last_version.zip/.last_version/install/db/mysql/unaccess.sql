drop table if exists awz_utm_role;
drop table if exists awz_utm_role_relation;
drop table if exists awz_utm_permission;