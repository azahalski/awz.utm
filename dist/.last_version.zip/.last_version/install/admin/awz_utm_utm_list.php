<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.utm/admin/utm_list.php");